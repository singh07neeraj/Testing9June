package com.inetbanking.testCases;

import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.inetbanking.pageObjects.CalculatorPage;

public class TC_CalculatorLayout_001 extends BaseClass {

	
	@Test
	public void CalculatorTitle() throws IOException {

		if (driver.getTitle().equals("The Online Calculator | Basic Calculator")) {
			Assert.assertTrue(true);
			logger.info("Calculator Title test passed");
		} else {
			captureScreen(driver, "Wrong Title");
			Assert.assertTrue(false);
			logger.info("Calculator Title test failed");
		}

	}

	@Test
	public void CalculatorLayoutButton() throws IOException {
		logger.info("Verfiy total layout Button");

		CalculatorPage lp = new CalculatorPage(driver);
		int totalbutton = lp.totalButton();

		if (totalbutton == 8) {
			Assert.assertTrue(true);
			logger.info("total button test passed , 8 button is present");
		} else {
			captureScreen(driver, "LayOut Button");
			Assert.assertTrue(false);
			logger.info("total button test failed");
		}

	}

	@Test
	public void ValidateNumber() throws IOException {
		logger.info("validate number Button");

		CalculatorPage lp = new CalculatorPage(driver);
		int numberbutton = lp.nuberbuttonValidator();

		if (numberbutton == 12) {
			Assert.assertTrue(true);
			logger.info("total button test passed , 12 button is present");
		} else {
			captureScreen(driver, "ValidateNumber");
			Assert.assertTrue(false);
			logger.info("total button test failed");
		}

	}

	@Test
	public void ValidateTextOperator() throws IOException {
		logger.info("validate Text Operator Button");

		CalculatorPage lp = new CalculatorPage(driver);

		if (lp.textboxDisplay()) {
			Assert.assertTrue(true);
			logger.info("Text Box Present");
		} else {
			captureScreen(driver, "ValidateOperator");
			Assert.assertTrue(false);
			logger.info("Text Box Not present");
		}

	}
}
