package com.inetbanking.testCases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.inetbanking.pageObjects.CalculatorPage;

public class TC_ArithmeticOperation_002 extends BaseClass {

	@Test
	public void ValidateSumOperation() throws IOException, InterruptedException {
		logger.info("validate Sum Operator Button");

		CalculatorPage lp = new CalculatorPage(driver);
		int firstValue = 10;
		int SecondValue = 20;
		lp.EnterFirstValue(String.valueOf(firstValue));
		lp.EnterOperator("add");
		lp.EnterFirstValue(String.valueOf(SecondValue));
		lp.equalButton();
		String finalString = lp.getTextField();
		int actualsum = firstValue + SecondValue;
		System.out.println("Final Vlaue is :" + finalString);
		if (finalString.equals(finalString.valueOf(actualsum))) {
			Assert.assertTrue(true);
			logger.info("Total Sum is working fine ");
		} else {
			captureScreen(driver, "ValidateSumOperation");
			Assert.assertTrue(false);
			logger.info("total sum is not working fine");
		}

	}

	@Test
	public void ValidatesubtractOperation() throws IOException, InterruptedException {
		logger.info("validate subtract Operator Button");

		CalculatorPage lp = new CalculatorPage(driver);
		int firstValue = 10;
		int SecondValue = 20;
		lp.EnterFirstValue(String.valueOf(firstValue));
		lp.EnterOperator("subtract");
		lp.EnterFirstValue(String.valueOf(SecondValue));
		lp.equalButton();
		String finalString = lp.getTextField();
		int actualsum = firstValue - SecondValue;
		System.out.println("Final Vlaue is :" + finalString);
		System.out.println("actualsum Vlaue is :" + actualsum);
		if (finalString.equals(finalString.valueOf(actualsum))) {
			Assert.assertTrue(true);
			logger.info("Total subtract is working fine ");
		} else {
			captureScreen(driver, "ValidatesubtractOperation");
			Assert.assertTrue(false);
			logger.info("total subtract is not working fine");
		}

	}

	@Test
	public void ValidatemultiplyOperation() throws IOException, InterruptedException {
		logger.info("validate multiply Operator Button");

		CalculatorPage lp = new CalculatorPage(driver);
		int firstValue = 10;
		int SecondValue = 20;
		lp.EnterFirstValue(String.valueOf(firstValue));
		lp.EnterOperator("multiply");
		lp.EnterFirstValue(String.valueOf(SecondValue));
		lp.equalButton();
		String finalString = lp.getTextField();
		int actualsum = firstValue * SecondValue;
		System.out.println("Final Vlaue is :" + finalString);
		System.out.println("actualsum Vlaue is :" + actualsum);
		if (finalString.equals(finalString.valueOf(actualsum))) {
			Assert.assertTrue(true);
			logger.info("Total multiply is working fine ");
		} else {
			captureScreen(driver, "ValidatemultiplyOperation");
			Assert.assertTrue(false);
			logger.info("total multiply is not working fine");
		}

	}

	@Test
	public void ValidatedivideOperation() throws IOException, InterruptedException {
		logger.info("validate multiply Operator Button");

		CalculatorPage lp = new CalculatorPage(driver);
		int firstValue = 10;
		int SecondValue = 10;
		int actualsum = 0;

		try {
			// performing divison and storing th result
			actualsum = firstValue / SecondValue;
			System.out.println("Division process has been done successfully.");
			System.out.println("Result came after division is: " + actualsum);
			lp.EnterFirstValue(String.valueOf(firstValue));
			lp.EnterOperator("divide");
			lp.EnterFirstValue(String.valueOf(SecondValue));
			lp.equalButton();
			String finalString = lp.getTextField();

			System.out.println("Final Vlaue is :" + finalString);
			System.out.println("actualsum Vlaue is :" + actualsum);
			if (finalString.equals(finalString.valueOf(actualsum))) {
				Assert.assertTrue(true);
				logger.info("Total multiply is working fine ");
			} else {
				captureScreen(driver, "ValidatedivideOperation");
				Assert.assertTrue(false);
				logger.info("total multiply is not working fine");
			}
		}
		// handling the exception in the catch block
		catch (java.lang.ArithmeticException ex) {
			captureScreen(driver, "ValidatedivideOperation");
			Assert.assertTrue(false);
			logger.info("total multiply is not working fine");
			System.out.println("Should avoid dividing by 0 " + ex);

		}

	}
	
	@Test
	public void ValidatClearButtonperation() throws IOException, InterruptedException {
		logger.info("validate Clear Button Operator Button");

		CalculatorPage lp = new CalculatorPage(driver);
		int firstValue = 10;
		lp.EnterFirstValue(String.valueOf(firstValue));
		lp.clearButton();
		String finalString = lp.getTextField();
		System.out.println("Clear Button :" + finalString);
		
		if (finalString.equals(finalString.valueOf(""))) {
			Assert.assertTrue(true);
			logger.info("clear button is working fine ");
		} else {
			captureScreen(driver, "ValidatClearButtonperation");
			Assert.assertTrue(false);
			logger.info("clear button is not working fine");
		}

	}

}
