package com.inetbanking.pageObjects;

import java.awt.peer.LabelPeer;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CalculatorPage {

	private static final By calButton1 = By.xpath("//div[@id='calculatorWrap']/form/div");
	private static final By numberbutton = By.xpath("//input[@class='button number']");
	private static final By operator = By.xpath("//input[@class=\"button operator\"]");
	private static final By displayText = By.xpath("//input[@name='multiply']");
	private static final By multiply = By.xpath("//input[@name='multiply']");
	private static final By divide = By.xpath("//input[@name='divide']");
	private static final By subtract = By.xpath("//input[@name='subtract']");
	private static final By add = By.xpath("//input[@name='add']");
	private static final By calculate = By.xpath("//input[@name='calculate']");
	private static final By clearButton = By.xpath("//input[@name='clearButton']");
	
	
	
	

	WebDriver ldriver;

	public CalculatorPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);

	}

	public int totalButton() {
		return ldriver.findElements(calButton1).size();
	}

	public int nuberbuttonValidator() {

		List<WebElement> elements = ldriver.findElements(numberbutton);
		return elements.size();

	}

	public int operatorValidate() {

		List<WebElement> elements = ldriver.findElements(operator);
		return elements.size();

	}

	public boolean textboxDisplay() {

		return ldriver.findElement(displayText).isDisplayed();

	}

	public void EnterFirstValue(String number) {

		ldriver.findElement(displayText).sendKeys(number);

	}

	public void EnterOperator(String Operator) {

		switch (Operator) {
		case "add":
			ldriver.findElement(add).click();

			break;
		case "divide":
			ldriver.findElement(divide).click();
			break;
		case "subtract":
			ldriver.findElement(subtract).click();
			break;
		case "multiply":
			ldriver.findElement(multiply).click();
			break;

		default:
			break;
		}

	}
	
	public String getTextField()
	{
		JavascriptExecutor js = (JavascriptExecutor)ldriver;
		 String textFinalValue=  js.executeScript("return document.getElementById('display').value").toString();
		return textFinalValue;
	}
	
	public void equalButton() {

		ldriver.findElement(calculate).click();;

	}
	public void clearButton() {

		ldriver.findElement(clearButton).click();;

	}

}
